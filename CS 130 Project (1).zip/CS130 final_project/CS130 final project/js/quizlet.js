// Basic quiz function

var members = prompt("How many countries are part of the Common Wealth?");

if(members!=56){
    window.alert("Sorry, wrong answer!")
    window.alert("The correct answer is 56 countries");
}

else{
    window.alert("Right answer, Congrats!");
}

window.alert("TRY AGAIN!")
var members = prompt("How many countries are part of the Common Wealth?");
